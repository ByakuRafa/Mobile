package com.example.conversor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button usd1 = (Button) findViewById(R.id.usd1);
        Button usd2 = (Button) findViewById(R.id.usd2);
        Button brl1 = (Button) findViewById(R.id.brl1);
        Button brl2 = (Button) findViewById(R.id.brl2);
        Button uyu1 = (Button) findViewById(R.id.uyu1);
        Button uyu2 = (Button) findViewById(R.id.uyu2);
        Button envia = (Button) findViewById(R.id.envia);
        TextView moeda1 = (TextView) findViewById(R.id.m1);
        TextView moeda2 = (TextView) findViewById(R.id.m2);
        EditText val1 = (EditText) findViewById(R.id.val1);
        EditText val2= (EditText) findViewById(R.id.val2);

        usd1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                moeda1.setText("USD");
            }
        });
        usd2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                moeda2.setText("USD");
            }
        });
        brl1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                moeda1.setText("BRL");
            }
        });
        brl2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                moeda2.setText("BRL");
            }
        });
        uyu1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                moeda1.setText("UYU");
            }
        });
        uyu2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                moeda2.setText("UYU");
            }
        });
        envia.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                val2.setText(""+converte(""+moeda1.getText(),""+moeda2.getText(),""+val1.getText()));
            }
        });
    }

    public Double converte(String m1, String m2, String v1){
        Double usdbrl=5.0 ,usduyu=40.0,brluyu=0.12,res=0.0;
        if (m1.equals("USD") && m2.equals("BRL")){res = Double.parseDouble(v1) *usdbrl;}
        if (m1.equals("BRL") && m2.equals("USD")){res = Double.parseDouble(v1) /usdbrl;}
        if (m1.equals("USD") && m2.equals("UYU")){res = Double.parseDouble(v1) *usduyu;}
        if (m1.equals("UYU") && m2.equals("USD")){res = Double.parseDouble(v1) /usduyu;}
        if (m1.equals("BRL") && m2.equals("UYU")){res = Double.parseDouble(v1) /brluyu;}
        if (m1.equals("UYU") && m2.equals("BRL")){res = Double.parseDouble(v1) *brluyu;}

        return res;
    }
}