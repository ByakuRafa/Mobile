package com.example.appapi;

import android.os.AsyncTask;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class tarefa extends AsyncTask<String,Void,String> {
    private TextView tv;
    public tarefa(TextView tv){
        this.tv = tv;
    }
    @Override
    protected String doInBackground(String... strings) {
        StringBuffer str = new StringBuffer();
        try{
            URL endereco = new URL(strings[0]);
            HttpsURLConnection conexao = (HttpsURLConnection) endereco.openConnection();
            InputStream input = conexao.getInputStream();
            InputStreamReader reader = new InputStreamReader(input);
            BufferedReader leitura = new BufferedReader(reader);
            String aux;
            while ((aux = leitura.readLine()) != null){
                str.append(aux);
            }
            System.out.println(str.toString());
        }
        catch (MalformedURLException e){ e.printStackTrace();}
        catch (IOException e){ e.printStackTrace();}

        return str.toString();
    }

    @Override
    protected void onPostExecute(String s) {
        JSONObject j = null;
        try {
            j = new JSONObject(s);
            tv.setText(j.getString("name"));

        }catch (JSONException e){
            e.printStackTrace();
        }

        super.onPostExecute(s);
    }
}
