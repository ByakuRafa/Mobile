package com.example.appapi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private EditText entrada;
    private TextView saida;
    private Button enviar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        entrada = (EditText) findViewById(R.id.texto);
        enviar = (Button) findViewById(R.id.btn);
        saida = (TextView) findViewById(R.id.ver);
        enviar.setOnClickListener(this);//(View.OnClickListener) this);
    }

    @Override
    public void onClick(View v){
        if(v.getId()==R.id.btn) {
            String url = "https://swapi.dev/api/people" + entrada.getText().toString().trim();

            tarefa t = new tarefa(saida);
            t.execute(url);
        }

    }
}