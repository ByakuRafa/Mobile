package com.example.dbactividade;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class bebidasDBOld extends SQLiteOpenHelper {

    private static final String TAG="sql";
    private static final String nome_banco ="bebida.sqlite";
    private static final int VERSAO = 1;

    public bebidasDBOld(@Nullable Context context) {
        super(context, nome_banco, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //db = db.openOrCreateDatabase();
        db.execSQL("CREATE TABLE IF NOT EXISTS bebidas(_id integer primary key autoincrement, nome text, preco flaot, lote integer, quantidade integer);");
        db.close();

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public long save(bebidas b ){
        long id = b.getId();
        SQLiteDatabase db = getWritableDatabase();
        try{
            ContentValues values = new ContentValues();
            values.put("nome",b.getNome());
            values.put("preco",b.getPreco());
            values.put("lote",b.getLote());
            values.put("quantidade",b.getQuantidade());
            if(id != 0){
                //update
                String _id = String.valueOf(id);
                String[] whereArgs = new String[]{_id};
                int count = db.update("bebidas",values,"_id=?", whereArgs);
                return count;
            }else{
                id = db.insert("bebidas","",values);
                return id;
            }
        }
        catch (Exception ex){

        }
        finally {
            db.close();
        }
        return 0;
    }

    public int delete(bebidas b){
        SQLiteDatabase db = getWritableDatabase();
        try{
            String _id = String.valueOf(b.getId());
            String[] whereArgs = new String[]{_id};
            int count = db.delete("bebidas","_id=?", whereArgs);
            return count;

        }catch (Exception a){

        }
        finally {
            db.close();
        }
        return 0;

    }

    public List<bebidas> findAll(){
        SQLiteDatabase db = getWritableDatabase();
        try {
            //Cursor c = db.query("bebidas",null,null,null,null,null,null,null);
            Cursor c = db.rawQuery("SELECT * FROM bebidas", null);
            return toList(c);
        }
        finally {
            db.close();
        }
    }
    @SuppressLint("Range")
    public List<bebidas> toList(Cursor c){
        List<bebidas> beb = new ArrayList<>();
        if(c.moveToFirst()){
            do {
                bebidas e = new bebidas();
                beb.add(e);
                e.setId(c.getInt(c.getColumnIndex("_id")));
                e.setNome(c.getString(c.getColumnIndex("nome")));
                e.setPreco(c.getFloat(c.getColumnIndex("preco")));
                e.setLote(c.getInt(c.getColumnIndex("lote")));
                e.setQuantidade(c.getInt(c.getColumnIndex("quantidade")));

            }while (c.moveToNext());
        }
        return beb;

    }
}
