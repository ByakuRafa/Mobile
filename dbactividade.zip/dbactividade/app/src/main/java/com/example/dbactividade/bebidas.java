package com.example.dbactividade;

import java.io.Serializable;

public class bebidas implements Serializable {

    private Integer id;
    private String nome;
    private Integer lote;
    private float preco;
    private Integer quantidade;


    public bebidas() {
        this.id = id;
        this.nome = "";
        this.lote = 0;
        this.preco = 0;
        this.quantidade = 0;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getLote() {
        return lote;
    }

    public void setLote(Integer lote) {
        this.lote = lote;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public Integer getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(Integer quantidade) {
        this.quantidade = quantidade;
    }

}
