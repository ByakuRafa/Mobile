package com.example.dbactividade;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class MainActivity extends AppCompatActivity {
    private EditText nome;
    private EditText id;
    private EditText preco;
    private EditText lote;
    private EditText quantidade;
    private Button btnSalva;
    private Button btnEdita;
    private Button btnDeleta;
    private Button btnvolta;
    private ListView lv;
    //private bebidasDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SQLiteDatabase db = openOrCreateDatabase("bebida", Context.MODE_PRIVATE,null);
        db.execSQL("CREATE TABLE IF NOT EXISTS bebidas(_id integer primary key autoincrement, nome text, preco flaot, lote integer, quantidade integer);");
        db.close();

        //db = new bebidasDB(this);
        nome = findViewById(R.id.nome);
        lote = findViewById(R.id.lote);
        preco = findViewById(R.id.preco);
        quantidade = findViewById(R.id.quan);
        id = findViewById(R.id.id);
        lv = findViewById(R.id.lista);
        //lista();
    }
    private int save(bebidas b){
        System.out.println("ENTRO NO SAVE!!!");



        System.out.println("nome: "+b.getNome());
        System.out.println("nome: "+b.getPreco());
        System.out.println("nome: "+b.getLote());
        System.out.println("nome: "+b.getQuantidade());
      //  int id = b.getId();
        SQLiteDatabase db = openOrCreateDatabase("bebida",Context.MODE_PRIVATE,null);
        try{
            ContentValues values = new ContentValues();
            values.put("nome",b.getNome());
            values.put("preco",b.getPreco());
            values.put("lote",b.getLote());
            values.put("quantidade",b.getQuantidade());
            if(Integer.parseInt(id.toString()) >= 0){
                //update
                String _id = String.valueOf(id);
                String[] whereArgs = new String[]{_id};
                int count = db.update("bebidas",values,"_id=?", whereArgs);
                return count;
            }else{
                int id = (int) db.insert("bebidas","",values);
            System.out.println("Ahahahahahah: "+id);
                return id;
           }
        }
        catch (Exception ex){

        }
        finally {
            db.close();
        }
        return 0;
    }

    private void lista(){
        lv = (ListView) findViewById(R.id.lista);
        SQLiteDatabase db = openOrCreateDatabase("bebida",Context.MODE_PRIVATE,null);
        Cursor c = db.query("bebidas",null ,null,null,null,null,null);
        //List<bebidas> lista = new List<bebidas>;
        List<String> lista = new ArrayList<String>();
        c.moveToFirst();
        lista.clear();
        do {
            lista.add( c.getString(0).toString()+ ":"+
                    c.getString(1).toString()+ ":"+
                    c.getString(2).toString()+ ":"+
                    c.getString(3).toString()+ ":"+
                    c.getString(4).toString());
        } while (c.moveToNext());
        ArrayAdapter<String> adaptador = new ArrayAdapter<String> (this,android.R.layout.simple_list_item_1,lista);
       // String[] ar = new String[lista.size()];
       // for(int i=0; i<lista.size(); i++){
      //      ar[i] = (String) lista.get(i).getNome()+" "+ lista.get(i).getPreco()+" "+ lista.get(i).getQuantidade()+" "+ lista.get(i).getLote();
       // }

        //final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_activated_1,ar);
        lv.setAdapter(adaptador);
    }
    public void salva(View view) {
        System.out.println("ENTRO NO SALVAAA");
        bebidas e = new bebidas();
        e.setNome(nome.getText().toString().trim());
        e.setPreco(Float.parseFloat(preco.getText().toString()));
        e.setLote(Integer.valueOf(lote.getText().toString().trim()));
        e.setQuantidade(Integer.parseInt(quantidade.getText().toString().trim()));
        save(e);
        lista();
    }

    public void deleta(View view) {
        lista();
    }
    public void selecionado(View view) {
        System.out.println("----------------------SELECT--------------------");

        System.out.println(view);

        System.out.println("----------------------SELECT--------------------");

    }

    public void edita(View view) {
        bebidas e = new bebidas();
        e.setId(Integer.valueOf(id.getText().toString().trim()));
        e.setNome(nome.getText().toString().trim());
        e.setPreco(Float.valueOf(String.valueOf(preco.getText())));
        e.setLote(Integer.valueOf(lote.getText().toString().trim()));
        e.setQuantidade(Integer.valueOf(quantidade.getText().toString().trim()));
        save(e);
        lista();
    }
    public void limpa(View view){
        nome.setText("");
        preco.setText("");
        lote.setText("");
        quantidade.setText("");
        id.setText("");
    }
}