package com.example.dbactividade;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class bebidasDB {
    private static final String TAG="sql";
    private static final String nome_banco ="bebida.sqlite";
    private static final int VERSAO = 1;
    private SQLiteDatabase db;

    public bebidasDB(@Nullable Context context ) {
    }

    public void onCreate() {
       // SQLiteDatabase db = this.db.openOrCreateDatabase(nome_banco,Context.MODE_PRIVATE,null);
       //db.execSQL("CREATE TABLE IF NOT EXISTS bebidas(_id integer primary key autoincrement, nome text, preco flaot, lote integer, quantidade integer);");
       // db.close();
        System.out.print("no soy usado");
    }
}
