package com.example.activitybymenu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.login_screen){
            Intent i = new Intent(getApplicationContext(),login.class);
            startActivity(i);
            return true;
        }
        if (id == R.id.contador){
            Intent i = new Intent(getApplicationContext(),contador.class);
            startActivity(i);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}