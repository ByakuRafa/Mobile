package com.example.activitybymenu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class logado extends AppCompatActivity {
    private TextView usuario;
    private Bundle data;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logado);
        usuario=findViewById(R.id.nome);
        Intent i = new Intent(this, MainActivity.class);
        startActivityForResult(i, 1);
        if(savedInstanceState!= null){
            data.putString("user", usuario.getText().toString());
            usuario.setText(""+savedInstanceState.getInt("user"));
        }
        usuario.setText(getIntent().getStringExtra("nome"));
    }

    @Override
    protected void onSaveInstanceState(Bundle data) {
        super.onSaveInstanceState(data);
        System.out.println("AAAA: " + usuario);
        data.putString("user", usuario.getText().toString());

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1) {
            if(resultCode == MainActivity.RESULT_OK){
                String result=data.getStringExtra("nome");
            }
            if (resultCode == MainActivity.RESULT_CANCELED) {
                // Write your code if there's no result
            }
        }
    } //onActivityResult
}