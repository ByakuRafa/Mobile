package com.example.activitybymenu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class contador extends AppCompatActivity {

    private TextView ver;
    private Button botao;
    private int i = 0;
    private Bundle data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contador);
        botao = findViewById(R.id.cont);
        ver = findViewById(R.id.ver);
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i++;
                ver.setText(""+i);
            }
        });
        if(savedInstanceState!= null){
            i = savedInstanceState.getInt("cont");
            ver.setText(""+savedInstanceState.getInt("cont"));
        }
    }
    @Override
    protected void onSaveInstanceState(Bundle data) {
        super.onSaveInstanceState(data);
        System.out.println("AAAA: "+i);
        data.putInt("cont", i);

    }
}