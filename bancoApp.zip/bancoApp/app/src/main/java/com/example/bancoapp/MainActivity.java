package com.example.bancoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText eNome;
    private EditText eCurso;
    private Button btnSalva;
    private Button btnBusca;
    private EstudanteDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        eNome = (EditText) findViewById(R.id.nome);
        eCurso = (EditText) findViewById(R.id.curso);
        btnBusca = (Button) findViewById(R.id.busca);
        btnSalva= (Button) findViewById(R.id.salva);
        eCurso = (EditText) findViewById(R.id.curso);
        btnBusca.setOnClickListener(this);
        btnSalva.setOnClickListener(this);
        db = new EstudanteDB(this);

    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.salva){
            Estudante e = new Estudante();
            e.setNome(eNome.getText().toString().trim());
            e.setCurso(eCurso.getText().toString().trim());
            db.save(e);
        }else if(v.getId()==R.id.busca){
            List<Estudante> l = db.findAll();
            for (int i=0; i<l.size();i++){
                Estudante a =l.get(i);
                System.out.println(a.getId() +" | "+ a.getNome()  +" | "+ a.getCurso());
            }
        }

    }
}