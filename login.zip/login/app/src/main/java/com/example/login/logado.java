package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class logado extends AppCompatActivity {
    private TextView usuario;
    private Bundle data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logado);
        usuario=findViewById(R.id.nome);
        if(savedInstanceState!= null){
            data.putString("user", usuario.getText().toString());
            usuario.setText(""+savedInstanceState.getInt("user"));
        }
        usuario.setText(getIntent().getStringExtra("nome"));
    }

    @Override
    protected void onSaveInstanceState(Bundle data) {
        super.onSaveInstanceState(data);
        System.out.println("AAAA: " + usuario);
        data.putString("user", usuario.getText().toString());

    }
}