package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText login;
    private EditText senha;
    private Button envia;
    private String log = "rafa", pass = "123";
  //  private Context contexto = getApplicationContext();
   // private String texto = "LOGIN ou Senha Errados";
   // private int duracao = Toast.LENGTH_SHORT;
   // private Toast toast = Toast.makeText(contexto, texto,duracao);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        envia = findViewById(R.id.send);
        login = findViewById(R.id.login);
        senha = findViewById(R.id.senha);
        envia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("TESTANDO LOGIN" +login.getText() +" senha: "+ senha.getText());
                if(login.getText().toString().equals(log) && senha.getText().toString().equals(pass)){
                    System.out.println("LOGADOOOOOO");
                    Intent i = new Intent(getApplicationContext(),logado.class);
                    i.putExtra("nome",login.getText().toString());
                    startActivity(i);
                }else{
                    System.out.println("NAO LOGOOU");
                    //toast.show();
                }
            }
        });



    }
}